package com.kotlin.samples.kotlinapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.kotlin.samples.kotlinapp.adapters.ModeloAdapter
import com.kotlin.samples.kotlinapp.model.Modelo
import com.kotlin.samples.kotlinapp.model.Movie
import kotlinx.android.synthetic.main.activity_simple_list_clase.*

class SimpleListClaseActivity : AppCompatActivity() {
    //5 componente visual listView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_list_clase)

        val modelos= getModelos()
        val modeloAdapter= ModeloAdapter(this,modelos)

        //5 asociar adapter a listview
        listView.adapter=modeloAdapter
    }

    //1 origen de datos
    fun getModelos():List<Modelo>{
        val movieList:MutableList<Modelo> = arrayListOf()

        movieList.add(Modelo(100, "Anita Santita",19,"anita19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(101, "Rosa Santita",19,"rosa19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(102, "Andrea Santita",19,"andrea19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(103, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(103, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(104, "Rosa Santita",19,"rosa19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(105, "Andrea Santita",19,"andrea19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(106, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(107, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(102, "Andrea Santita",19,"andrea19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(103, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(103, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(104, "Rosa Santita",19,"rosa19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(105, "Andrea Santita",19,"andrea19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(106, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        movieList.add(Modelo(107, "Jimena Santita",19,"jimena19@hotmail.com",
                R.drawable.ic_anita))

        return  movieList.toList()
    }
}
