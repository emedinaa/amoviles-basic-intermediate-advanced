package com.kotlin.samples.kotlinapp

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.widget.Toast
import com.kotlin.samples.kotlinapp.adapters.MovieGridAdapter
import com.kotlin.samples.kotlinapp.adapters.MovieListAdapter
import com.kotlin.samples.kotlinapp.data.Movies
import com.kotlin.samples.kotlinapp.extensions.toast
import com.kotlin.samples.kotlinapp.model.Movie
import kotlinx.android.synthetic.main.activity_movie_grid.*

class MovieGridActivity : AppCompatActivity() {

    private var movies:List<Movie> = arrayListOf()
    private var adapter: MovieGridAdapter?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_grid)

        movies= Movies.getMovies()

        //adapter
        adapter= MovieGridAdapter(this,movies)

        //set Adapter to UI
        gridViewMovies.adapter= adapter

        //events
        gridViewMovies.setOnItemClickListener { adapterView, view, position, l ->
            val movie=  adapterView.adapter.getItem(position) as Movie
            val item= "$position : ${movie.title}  ${movie.cartelera}"

            toast(item, Toast.LENGTH_SHORT)
        }
    }
}
