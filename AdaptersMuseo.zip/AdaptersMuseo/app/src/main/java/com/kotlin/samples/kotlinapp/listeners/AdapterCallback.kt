package com.kotlin.samples.kotlinapp.listeners

import com.kotlin.samples.kotlinapp.model.Museo

interface AdapterCallback {

    fun onItemSelected(museo:Museo)
}