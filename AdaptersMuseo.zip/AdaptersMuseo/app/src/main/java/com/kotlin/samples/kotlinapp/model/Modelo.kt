package com.kotlin.samples.kotlinapp.model

// 2 Entidad
class Modelo(val id:Int,val name:String, val age:Int, val email:String,
             val photo:Int) {
}