package com.kotlin.samples.kotlinapp.adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.kotlin.samples.kotlinapp.R
import com.kotlin.samples.kotlinapp.model.Modelo
/*
    4 Adapter
 */
class ModeloAdapter(private val context: Context,
                    private val data:List<Modelo>):BaseAdapter() {

    private val mInflater: LayoutInflater = LayoutInflater.from(context)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View ?{

        val view: View?

        val vh: RowHolder

        if (convertView == null) {
            //cargar la celda xml
            //convertir la celda a View
            view = mInflater.inflate(R.layout.row_modelo, parent, false)
            vh = RowHolder(view)
            view?.tag = vh
        } else {
            view = convertView
            vh = view.tag as RowHolder
        }

        //obtener modelo
        val modelo= data[position]

        //pintar la informacion del modelo al view
        vh.textViewName.text =  modelo.name
        vh.texViewEmail.text =  modelo.email
        vh.imageViewModelo.setImageResource(modelo.photo)

        if(position==2){
            vh.textViewName.setTextColor(Color.parseColor("#ff00ff"))
        }else{
            vh.textViewName.setTextColor(Color.parseColor("#000000"))
        }

        //retornar view
        return view
    }

    override fun getItem(position: Int): Any {
       //data.get(position)
        return data[position]
    }

    override fun getItemId(position: Int): Long {
        return 0
    }

    override fun getCount(): Int {
        return data.size
    }

    private class RowHolder(row: View?) {
        val textViewName: TextView = row?.findViewById(R.id.textViewName) as TextView
        val texViewEmail: TextView = row?.findViewById(R.id.texViewEmail) as TextView
        val imageViewModelo: ImageView = row?.findViewById(R.id.imageViewModelo) as ImageView
    }
}