package com.kotlin.samples.kotlinapp.model

import java.io.Serializable

class Entity(val id:Int,val title:String,subTitle:String):Serializable {
}