package com.kotlin.samples.kotlinapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.kotlin.samples.kotlinapp.model.Museo
import kotlinx.android.synthetic.main.activity_museo_detalle.*

class MuseoDetalleActivity : AppCompatActivity() {

    private var museo:Museo?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_museo_detalle)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        verifyExtras()

        populate()
    }

    private fun populate(){

        //textViewName.text= museo.name
        museo?.let {
            textViewName.text= it.name
            imageView.setImageResource(it.photo)
        }
    }

    private fun verifyExtras(){
        intent?.extras?.let {

            if(it.getSerializable("MUSEO") is Museo){
                museo= it.getSerializable("MUSEO") as Museo
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}
