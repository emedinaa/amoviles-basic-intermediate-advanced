package com.kotlin.samples.kotlinapp.adapters

import android.content.Intent
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import com.kotlin.samples.kotlinapp.MuseoDetalleActivity
import com.kotlin.samples.kotlinapp.R
import com.kotlin.samples.kotlinapp.listeners.AdapterCallback
import com.kotlin.samples.kotlinapp.model.Museo

class MuseoAdapter(val museos:List<Museo>, val callback:AdapterCallback):RecyclerView.Adapter<MuseoAdapter.MViewHolder>(){

    override fun onCreateViewHolder(parent: ViewGroup, p1: Int): MViewHolder {
        // create a new view
        val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.row_museo, parent, false)
        // set the view's size, margins, paddings and layout parameters

        return MViewHolder(view)
    }

    override fun onBindViewHolder(vh: MViewHolder, position: Int) {
        val museo= museos[position]

        //render
        vh.textViewName.text= museo.name
        vh.imageView.setImageResource(museo.photo)

        //events
        vh.textViewLink.setOnClickListener {
            //ir a la pantalla de detalle
            //goToMuseo(museo)
            callback.onItemSelected(museo)
        }
    }

    /*private fun goToMuseo(museo:Museo){
        val intent= Intent(this, MuseoDetalleActivity::class.java)
        val bundle= Bundle()
        bundle.putSerializable("MUSEO",museo)
        intent.putExtras(bundle)

        startActivity(intent)
    }*/

    override fun getItemCount(): Int {
        return museos.size
    }


    class MViewHolder(val view: View) :RecyclerView.ViewHolder(view){
        val textViewName:TextView= view.findViewById(R.id.textViewName)
        val imageView:ImageView= view.findViewById(R.id.imageView)
        val textViewLink:TextView= view.findViewById(R.id.textViewLink)
        val imageViewFavorite:ImageView= view.findViewById(R.id.imageViewFavorite)
    }

}