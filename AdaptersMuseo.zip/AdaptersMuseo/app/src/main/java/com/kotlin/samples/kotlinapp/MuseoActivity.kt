package com.kotlin.samples.kotlinapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.GridLayoutManager
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.Toast
import com.kotlin.samples.kotlinapp.adapters.MuseoAdapter
import com.kotlin.samples.kotlinapp.extensions.toast
import com.kotlin.samples.kotlinapp.listeners.AdapterCallback
import com.kotlin.samples.kotlinapp.listeners.RecyclerClickListener
import com.kotlin.samples.kotlinapp.listeners.RecyclerTouchListener
import com.kotlin.samples.kotlinapp.model.Movie
import com.kotlin.samples.kotlinapp.model.Museo
import kotlinx.android.synthetic.main.activity_museo.*
import java.text.FieldPosition

class MuseoActivity : AppCompatActivity(),AdapterCallback {

    private lateinit var museoAdapter: RecyclerView.Adapter<*>
    private lateinit var viewManager: RecyclerView.LayoutManager
    private var museos:List<Museo> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_museo)

        //recyclerview
        //viewManager = LinearLayoutManager(this)
        viewManager = GridLayoutManager(this,3)
        recyclerView.layoutManager=viewManager

        //cargar museos
        museos= getMuseos()
        /*museoAdapter= MuseoAdapter(museos,object :AdapterCallback{
            override fun onItemSelected(museo: Museo) {

            }
        })*/
        museoAdapter= MuseoAdapter(museos,this)

        recyclerView.adapter=museoAdapter

        //events
        /*recyclerView.addOnItemTouchListener(RecyclerTouchListener(
                this,recyclerView,object:RecyclerClickListener{
            override fun onClick(view: View, position: Int) {
                //showItem(position)
                val museo= museos[position]
                goToMuseo(museo)
            }

            override fun onLongClick(view: View, position: Int) {

            }
        }
        ))*/

    }

    private fun goToMuseo(museo:Museo){
        val intent= Intent(this,MuseoDetalleActivity::class.java)
        val bundle= Bundle()
        bundle.putSerializable("MUSEO",museo)
        intent.putExtras(bundle)

        startActivity(intent)
    }

    private fun showItem(position: Int){
      //Toast.makeText(this, )
        toast(museos[position].toString(),Toast.LENGTH_SHORT)
    }

    override fun onItemSelected(museo: Museo) {
        goToMuseo(museo)
    }

    fun getMuseos():List<Museo>{
        val museoList:MutableList<Museo> = arrayListOf()
        museoList.add(Museo(1,"Museo Nacional de Arqueología, Antropología e Historia del Perú",
                R.drawable.ic_01))
        museoList.add(Museo(2,"Museo de Sitio Pachacamac",
                R.drawable.ic_02))
        museoList.add(Museo(3,"Casa Museo José Carlos Mariátegui'",
                R.drawable.ic_03))
        museoList.add(Museo(4,"Museo de Sitio Julio C. Tello' de Paracas",
                R.drawable.ic_04))
        museoList.add(Museo(5,"Museo Regional de Ica",
                R.drawable.ic_05))
        museoList.add(Museo(6,"Museo de Arte Italiano",
                R.drawable.ic_07))
        museoList.add(Museo(7,"Museo de Sitio \"Arturo Jiménez Borja\" - Puruchuco",
                R.drawable.ic_08))
        museoList.add(Museo(8,"Lugar de la Memoria, la Tolerancia y la Inclusión Social",
                R.drawable.ic_09))
        museoList.add(Museo(9,"Museo Nacional de la Cultura Peruana",0))

        return  museoList.toList()
    }
}
