package com.kotlin.samples.kotlinapp

class Entity(val id:Int, val name:String) {
}