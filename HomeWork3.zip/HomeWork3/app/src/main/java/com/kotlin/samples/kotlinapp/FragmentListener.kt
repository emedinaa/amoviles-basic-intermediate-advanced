package com.kotlin.samples.kotlinapp

interface FragmentListener {

    fun enviarEntity(entity:Entity)
}