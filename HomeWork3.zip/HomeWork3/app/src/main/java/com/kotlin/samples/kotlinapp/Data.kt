package com.kotlin.samples.kotlinapp

object Data {

    fun getData():List<Entity>{

        val mutableList= mutableListOf<Entity>()
        mutableList.add(Entity(1,"demo"))
        mutableList.add(Entity(2,"demo"))
        mutableList.add(Entity(3,"demo"))
        mutableList.add(Entity(4,"demo"))
        mutableList.add(Entity(5,"demo"))

        return  mutableList.toList()
    }
}