package com.kotlin.samples.kotlinapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity(),FragmentListener {

    private var fragmentLeft:LeftFragment?=null
    private var fragmentRight:RightFragment?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        fragmentLeft= supportFragmentManager.findFragmentById(R.id.fragmentLeft) as LeftFragment
        fragmentRight= supportFragmentManager.findFragmentById(R.id.fragmentRight) as RightFragment
    }

    override fun enviarEntity(entity: Entity) {

    }
}
